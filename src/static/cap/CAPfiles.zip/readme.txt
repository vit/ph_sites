The author's package contains:



CAP-journal.cls - the LaTeX class file for CAP;

CAPauthor.tex   - the template that should be modified by the author;

CAPauthor.pdf   - the template compiled to PDF;

CAP.bst         - the BiBTeX style file for CAP;

CAPsample.bib   - a sample bibliography file.  
